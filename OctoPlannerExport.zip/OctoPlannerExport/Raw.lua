-- Octo Planner Export: the full record (WoW 1.12 / Lua 5.0)
-- While /ope log is on, this saves everything, in and out of combat, with the time since the log started:
--   every combat text line (you, your group, other players, enemies, pets), resets and boss emotes,
--   every spell cast near you with who cast it and on whom (SuperWoW): buffs, totems, blessings, heals, enemy casts,
--   your energy, rage, mana and health as they change (ticks, Furor, rage from hits),
--   your group and any swaps, your target, your zone, and when you enter and leave combat,
--   and the loot and money you and your group get,
--   and where you and your group stand: every second in combat, every 5 seconds out of combat (SuperWoW).
-- The planner splits it up. Lines: "time<TAB>code<TAB>text".

-- 400,000 lines covers a full 40-man Molten Core (200,000 ran out after about an hour)
local MAX_EV = 400000

-- other people's "gains 164 Mana from ..." lines are about a tenth of a raid log and the planner never uses them
local function skipLine(text)
  if not text then return false end
  local _, _, kind = string.find(text, "^%S+ gains %d+ (%a+) from ")
  return kind == "Mana" or kind == "Rage" or kind == "Energy"
end

-- combat text channels, saved as their number to keep the file small (the planner has the same list)
local CH = {
  "CHAT_MSG_COMBAT_SELF_HITS", "CHAT_MSG_COMBAT_SELF_MISSES", "CHAT_MSG_COMBAT_PET_HITS", "CHAT_MSG_COMBAT_PET_MISSES",
  "CHAT_MSG_COMBAT_PARTY_HITS", "CHAT_MSG_COMBAT_PARTY_MISSES", "CHAT_MSG_COMBAT_FRIENDLYPLAYER_HITS", "CHAT_MSG_COMBAT_FRIENDLYPLAYER_MISSES",
  "CHAT_MSG_COMBAT_HOSTILEPLAYER_HITS", "CHAT_MSG_COMBAT_HOSTILEPLAYER_MISSES", "CHAT_MSG_COMBAT_CREATURE_VS_SELF_HITS", "CHAT_MSG_COMBAT_CREATURE_VS_SELF_MISSES",
  "CHAT_MSG_COMBAT_CREATURE_VS_PARTY_HITS", "CHAT_MSG_COMBAT_CREATURE_VS_PARTY_MISSES", "CHAT_MSG_COMBAT_CREATURE_VS_CREATURE_HITS", "CHAT_MSG_COMBAT_CREATURE_VS_CREATURE_MISSES",
  "CHAT_MSG_COMBAT_FRIENDLY_DEATH", "CHAT_MSG_COMBAT_HOSTILE_DEATH", "CHAT_MSG_COMBAT_XP_GAIN",
  "CHAT_MSG_SPELL_SELF_DAMAGE", "CHAT_MSG_SPELL_SELF_BUFF", "CHAT_MSG_SPELL_PET_DAMAGE", "CHAT_MSG_SPELL_PET_BUFF",
  "CHAT_MSG_SPELL_PARTY_DAMAGE", "CHAT_MSG_SPELL_PARTY_BUFF", "CHAT_MSG_SPELL_FRIENDLYPLAYER_DAMAGE", "CHAT_MSG_SPELL_FRIENDLYPLAYER_BUFF",
  "CHAT_MSG_SPELL_HOSTILEPLAYER_DAMAGE", "CHAT_MSG_SPELL_HOSTILEPLAYER_BUFF", "CHAT_MSG_SPELL_CREATURE_VS_SELF_DAMAGE", "CHAT_MSG_SPELL_CREATURE_VS_SELF_BUFF",
  "CHAT_MSG_SPELL_CREATURE_VS_PARTY_DAMAGE", "CHAT_MSG_SPELL_CREATURE_VS_PARTY_BUFF", "CHAT_MSG_SPELL_CREATURE_VS_CREATURE_DAMAGE", "CHAT_MSG_SPELL_CREATURE_VS_CREATURE_BUFF",
  "CHAT_MSG_SPELL_DAMAGESHIELDS_ON_SELF", "CHAT_MSG_SPELL_DAMAGESHIELDS_ON_OTHERS", "CHAT_MSG_SPELL_AURA_GONE_SELF", "CHAT_MSG_SPELL_AURA_GONE_PARTY",
  "CHAT_MSG_SPELL_AURA_GONE_OTHER", "CHAT_MSG_SPELL_ITEM_ENCHANTMENTS", "CHAT_MSG_SPELL_BREAK_AURA",
  "CHAT_MSG_SPELL_PERIODIC_SELF_DAMAGE", "CHAT_MSG_SPELL_PERIODIC_SELF_BUFFS", "CHAT_MSG_SPELL_PERIODIC_PARTY_DAMAGE", "CHAT_MSG_SPELL_PERIODIC_PARTY_BUFFS",
  "CHAT_MSG_SPELL_PERIODIC_FRIENDLYPLAYER_DAMAGE", "CHAT_MSG_SPELL_PERIODIC_FRIENDLYPLAYER_BUFFS", "CHAT_MSG_SPELL_PERIODIC_HOSTILEPLAYER_DAMAGE", "CHAT_MSG_SPELL_PERIODIC_HOSTILEPLAYER_BUFFS",
  "CHAT_MSG_SPELL_PERIODIC_CREATURE_DAMAGE", "CHAT_MSG_SPELL_PERIODIC_CREATURE_BUFFS", "CHAT_MSG_SPELL_FAILED_LOCALPLAYER",
  "CHAT_MSG_MONSTER_EMOTE", "CHAT_MSG_MONSTER_YELL", "CHAT_MSG_SYSTEM", "CHAT_MSG_LOOT", "CHAT_MSG_MONEY"
}
local CHN = {}
for i, e in ipairs(CH) do CHN[e] = i end

local LOG, G0 = nil, 0
local full, warned = false, false
local gapAt = nil
local function clock() return GetTime() - G0 end
-- (re)attach to the running log; after a /reload, line the clock up again from the real time
local function attach()
  local l = OPE_CurrentLog and OPE_CurrentLog()
  if l ~= LOG then
    LOG = l; full = false
    if LOG then
      if not LOG.t0 then LOG.t0 = time(); LOG.ev = {}; G0 = GetTime()
      else
        G0 = GetTime() - (time() - LOG.t0)
        -- picked up again after a log out or disconnect: note how long nothing was recorded
        local ev, last = LOG.ev or {}, nil
        local n = table.getn(ev)
        if n > 0 then local _, _, t = string.find(ev[n], "^([%d%.]+)\t"); last = tonumber(t) end
        last = last or LOG.lastT
        if last and (time() - LOG.t0) - last > 60 then gapAt = math.floor((time() - LOG.t0) - last) end
      end
      LOG.ev = LOG.ev or {}
    end
  end
  return LOG
end
-- ---------- parts written to files (SuperWoW ExportFile) ----------
-- With SuperWoW the record is written in parts to the game's "imports" folder (octo_<start>_001.txt, ...),
-- so it never fills up and a crash only loses the last few minutes. Only lines that were written and read
-- back are taken out of the saved file. Without SuperWoW everything stays in the saved file as before.
local CHUNK = 15000
local exportBroken, exportSaid = false, false
local function flush(force)
  if not LOG or exportBroken or not ExportFile or not ImportFile then return end
  local ev = LOG.ev
  local n = table.getn(ev)
  if n == 0 or (not force and n < CHUNK) then return end
  local part = (LOG.parts or 0) + 1
  local name = string.format("octo_%d_%03d.txt", math.floor(LOG.t0 or 0), part)
  local head = "#octo\t" .. (UnitName("player") or "?") .. "\t" .. (GetRealmName and GetRealmName() or "") .. "\t" .. (LOG.t0 or 0) .. "\t" .. part .. "\t" .. (LOG.label or "")
  local text = head .. "\n" .. table.concat(ev, "\n") .. "\n"
  local ok = pcall(ExportFile, name, text)
  local okr, got = pcall(ImportFile, name)
  if not ok or not okr or type(got) ~= "string" or string.len(got) < string.len(text) - 2 then
    exportBroken = true
    DEFAULT_CHAT_FRAME:AddMessage("|cff9f7aea[Octo Planner Export]|r Could not write the log to the game's imports folder (make a folder named imports next to WoW.exe). It stays in the saved file instead.")
    return
  end
  LOG.parts = part
  LOG.files = LOG.files or {}
  table.insert(LOG.files, name)
  LOG.ev = {}
  full, warned = false, false
  if not exportSaid then
    exportSaid = true
    DEFAULT_CHAT_FRAME:AddMessage("|cff9f7aea[Octo Planner Export]|r The log is being written in parts to your game's imports folder (" .. name .. "). They go back into OctoPlannerExport.lua when the log stops or you log in again, so that one file is all you upload.")
  end
end
OPE_LogFlush = flush

-- the parts are read back into the saved file (log.full), so OctoPlannerExport.lua alone holds the whole log:
-- when the log stops, and at login for any log with parts that aren't in yet. The part files stay as a backup.
local function join(L)
  if not L or not L.files or not ImportFile then return end
  local out, n = {}, 0
  for _, name in ipairs(L.files) do
    local ok, text = pcall(ImportFile, name)
    -- a part is missing: keep what was saved before, the planner names the missing files
    if not ok or type(text) ~= "string" then return end
    for line in string.gfind(text, "[^\r\n]+") do
      if string.sub(line, 1, 5) ~= "#octo" then n = n + 1; out[n] = line end
    end
  end
  L.full = out
  L.fullParts = table.getn(L.files)
end
OPE_LogJoin = join
local jf = CreateFrame("Frame")
jf:RegisterEvent("PLAYER_ENTERING_WORLD")
jf:SetScript("OnEvent", function()
  jf:UnregisterEvent("PLAYER_ENTERING_WORLD")
  local db = OctoPlannerExportDB
  local c = db and db.chars and db.chars[(UnitName("player") or "?") .. " - " .. (GetRealmName() or "?")]
  if not c or not c.logs then return end
  for _, L in ipairs(c.logs) do
    if L.files and (L.fullParts or 0) < table.getn(L.files) then join(L) end
  end
end)

local function put(code, text)
  if not attach() or full then return end
  if table.getn(LOG.ev) >= CHUNK * 2 or (table.getn(LOG.ev) >= CHUNK and not UnitAffectingCombat("player")) then flush() end
  local ev = LOG.ev
  if table.getn(ev) >= MAX_EV then
    full = true
    DEFAULT_CHAT_FRAME:AddMessage("|cff9f7aea[Octo Planner Export]|r The full record is full (" .. MAX_EV .. " lines). Fight summaries keep going. /ope log <new name> starts a fresh one.")
    pcall(function() UIErrorsFrame:AddMessage("Octo log is full. /ope log <new name> starts a new one.", 1, 0.3, 0.3, 1, 8) end)
    return
  end
  if gapAt then local g = gapAt; gapAt = nil; table.insert(ev, string.format("%.1f\t%s\t%s", clock(), "L", g)) end
  if not warned and table.getn(ev) >= MAX_EV * 0.9 then
    warned = true
    DEFAULT_CHAT_FRAME:AddMessage("|cff9f7aea[Octo Planner Export]|r The full record is 90% full. /ope log <new name> saves it and starts a new one.")
  end
  local c = clock()
  LOG.lastT = c
  table.insert(ev, string.format("%.1f\t%s\t%s", c, code, text or ""))
end

-- ---------- group ----------
local lastGroup = ""
local function groupNow()
  local out = {}
  local function add(u, sub)
    if not UnitExists(u) then return end
    local _, cls = UnitClass(u)
    table.insert(out, (UnitName(u) or "?") .. ":" .. (cls or "?") .. ":" .. (UnitLevel(u) or 0) .. ":" .. (sub or 0))
  end
  local n = GetNumRaidMembers and GetNumRaidMembers() or 0
  if n > 0 then
    for i = 1, n do local name, _, sub = GetRaidRosterInfo(i); if name then add("raid" .. i, sub) end end
  else
    add("player", 1)
    for i = 1, GetNumPartyMembers() do add("party" .. i, 1) end
  end
  table.sort(out)
  return table.concat(out, ",")
end
local function checkGroup(force)
  local g = groupNow()
  if force or g ~= lastGroup then lastGroup = g; put("G", g) end
end

-- ---------- your energy, rage, mana and health ----------
local last = {}
local function power()
  local p = UnitMana("player") or 0
  local t = UnitPowerType and UnitPowerType("player") or 0
  local key = "P" .. t
  if last.pt ~= t or last.p ~= p then last.pt = t; last.p = p; put(key, p .. "/" .. (UnitManaMax("player") or 0)) end
end
local function health()
  local h = UnitHealth("player") or 0
  if last.h ~= h then last.h = h; put("H", h .. "/" .. (UnitHealthMax("player") or 0)) end
end

-- ---------- every cast near you (SuperWoW) ----------
local names = {}
local function nameOf(guid)
  if not guid or guid == "" or guid == "0x0000000000000000" then return "" end
  local n = names[guid]
  if n then return n end
  -- your own casts: right after a login or /reload the game can still answer "Unknown" for your own GUID
  local _, me = UnitExists("player")
  if guid == me then n = UnitName("player") or "" else n = UnitName(guid) or "" end
  -- "Unknown" is never kept, so the real name is asked again on the next cast
  if n ~= "" and n ~= "Unknown" and n ~= UNKNOWNOBJECT then names[guid] = n end
  return n
end

local ev = CreateFrame("Frame")
for _, e in ipairs(CH) do ev:RegisterEvent(e) end
for _, e in ipairs({ "UNIT_ENERGY", "UNIT_RAGE", "UNIT_MANA", "UNIT_HEALTH", "UNIT_DISPLAYPOWER", "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED",
  "PLAYER_TARGET_CHANGED", "PARTY_MEMBERS_CHANGED", "RAID_ROSTER_UPDATE", "ZONE_CHANGED_NEW_AREA", "PLAYER_ENTERING_WORLD", "PLAYER_DEAD", "PLAYER_UNGHOST" }) do
  ev:RegisterEvent(e)
end
pcall(function() ev:RegisterEvent("UNIT_CASTEVENT") end)
local wasOn = false
ev:SetScript("OnEvent", function()
  if not attach() then wasOn = false return end
  if not wasOn then
    -- first event of a new or resumed log: write where we are and who is with us
    wasOn = true
    put("Z", (GetRealZoneText and GetRealZoneText() or "") .. "|" .. (GetSubZoneText and GetSubZoneText() or ""))
    checkGroup(true); last = {}; power(); health()
  end
  local c = CHN[event]
  if c then if not skipLine(arg1) then put(c, arg1) end return end
  if event == "UNIT_CASTEVENT" then
    if arg3 == "MAINHAND" or arg3 == "OFFHAND" then return end
    local sn, rank = "", ""
    if SpellInfo then sn, rank = SpellInfo(arg4) end
    put("S", arg3 .. "|" .. nameOf(arg1) .. "|" .. nameOf(arg2) .. "|" .. (sn or arg4 or "") .. "|" .. (rank or "") .. "|" .. (arg4 or "") .. "|" .. (arg5 or 0))
  elseif event == "UNIT_ENERGY" or event == "UNIT_RAGE" or event == "UNIT_MANA" or event == "UNIT_DISPLAYPOWER" then
    if arg1 == "player" then power() end
  elseif event == "UNIT_HEALTH" then
    if arg1 == "player" then health() end
  elseif event == "PLAYER_REGEN_DISABLED" then put("C", "1")
  elseif event == "PLAYER_REGEN_ENABLED" then put("C", "0")
  elseif event == "PLAYER_TARGET_CHANGED" then
    local _, guid = UnitExists("target")
    put("T", (UnitName("target") or "") .. "|" .. (UnitLevel("target") or "") .. "|" .. (UnitClassification and UnitClassification("target") or "") .. "|" .. (type(guid) == "string" and guid or ""))
  elseif event == "PARTY_MEMBERS_CHANGED" or event == "RAID_ROSTER_UPDATE" then checkGroup()
  elseif event == "ZONE_CHANGED_NEW_AREA" or event == "PLAYER_ENTERING_WORLD" then
    put("Z", (GetRealZoneText and GetRealZoneText() or "") .. "|" .. (GetSubZoneText and GetSubZoneText() or ""))
    checkGroup()
  elseif event == "PLAYER_DEAD" then put("D", "1")
  elseif event == "PLAYER_UNGHOST" then put("D", "0")
  end
end)

-- ---------- where everyone stands ----------
-- "X" lines: name:x:y;name:x:y in world yards (SuperWoW UnitPosition). Only people who moved more than a yard,
-- plus everyone every 10 seconds. Without SuperWoW, "Y" lines use the map position (0-1000) where the zone has a map.
local posLast, posFull, posT = {}, 0, 0
local posNow = {}
local function units()
  local u = {}
  local n = GetNumRaidMembers and GetNumRaidMembers() or 0
  if n > 0 then for i = 1, n do table.insert(u, "raid" .. i) end
  else table.insert(u, "player"); for i = 1, GetNumPartyMembers() do table.insert(u, "party" .. i) end end
  return u
end
local function samplePos()
  local now = GetTime()
  local all = now - posFull >= 10
  if all then posFull = now end
  local out, code = {}, "X"
  posNow = {}
  local useMap = not UnitPosition
  if useMap then
    if WorldMapFrame and WorldMapFrame:IsVisible() then return end
    if SetMapToCurrentZone then SetMapToCurrentZone() end
    code = "Y"
  end
  for _, u in ipairs(units()) do
    if UnitExists(u) and not UnitIsDeadOrGhost(u) then
      local name = UnitName(u)
      local x, y
      if useMap then
        local a, b = GetPlayerMapPosition(u)
        if a and (a > 0 or b > 0) then x, y = math.floor(a * 1000 + 0.5), math.floor(b * 1000 + 0.5) end
      else
        local ok, a, b = pcall(UnitPosition, u)
        if ok and a then x, y = math.floor(a * 10 + 0.5) / 10, math.floor(b * 10 + 0.5) / 10; table.insert(posNow, { u, a, b }) end
      end
      if name and x then
        local l = posLast[name]
        if all or not l or math.abs(l[1] - x) + math.abs(l[2] - y) >= 1 then
          posLast[name] = { x, y }
          table.insert(out, name .. ":" .. x .. ":" .. y)
        end
      end
    end
  end
  if table.getn(out) > 0 then put(code, table.concat(out, ";")) end
end
-- "B" lines: where the bosses stand and which way they face, from what the raid has targeted (SuperWoW).
-- boss:x:y:facing:health%:target;...  facing in radians when the game gives it, else empty (the planner then
-- points the boss at its target). Only bosses (skull level or world boss), only in combat, only when something
-- changed, plus every 5 seconds.
local function pct(v, m) if not v or not m or m <= 0 then return 0 end return math.floor(v / m * 100 + 0.5) end
local bossLast, bossFull = {}, 0
-- SuperWoW only gives positions of friendly units, so a boss is found from how far raid members are from it
-- (UnitXP distanceBetween), like a GPS: least squares over up to 8 members. Rough by a yard or two.
local function bossPos(t)
  local ok, a, b = pcall(UnitPosition, t)
  if ok and a then return a, b end
  if not UnitXP then return nil end
  local P = {}
  for _, m in ipairs(posNow) do
    local okd, d = pcall(UnitXP, "distanceBetween", m[1], t)
    if okd and type(d) == "number" and d >= 0 and d < 100 then table.insert(P, { m[2], m[3], d }) end
    if table.getn(P) >= 8 then break end
  end
  local n = table.getn(P)
  if n < 3 then return nil end
  local x0, y0, d0 = P[1][1], P[1][2], P[1][3]
  local a11, a12, a22, b1, b2 = 0, 0, 0, 0, 0
  for i = 2, n do
    local ax, ay = 2 * (P[i][1] - x0), 2 * (P[i][2] - y0)
    local rhs = d0 * d0 - P[i][3] * P[i][3] + P[i][1] * P[i][1] - x0 * x0 + P[i][2] * P[i][2] - y0 * y0
    a11 = a11 + ax * ax; a12 = a12 + ax * ay; a22 = a22 + ay * ay; b1 = b1 + ax * rhs; b2 = b2 + ay * rhs
  end
  local det = a11 * a22 - a12 * a12
  if math.abs(det) < 0.001 then return nil end
  return (b1 * a22 - b2 * a12) / det, (a11 * b2 - a12 * b1) / det
end
local function sampleBoss()
  if not UnitPosition then return end
  local now = GetTime()
  local all = now - bossFull >= 5
  if all then bossFull = now end
  local out, seen = {}, {}
  for _, u in ipairs(units()) do
    local t = u .. "target"
    if UnitExists(t) and UnitCanAttack("player", t) and not UnitIsDead(t) then
      local c, lv = UnitClassification(t), UnitLevel(t)
      -- raid bosses (skull level), and dungeon bosses: elite and at least 2 levels above you
      if c == "worldboss" or lv == -1 or ((c == "elite" or c == "rareelite") and lv >= (UnitLevel("player") or 60) + 2) then
        local _, guid = UnitExists(t)
        local name = UnitName(t)
        local key = guid or name
        if name and not seen[key] then
          seen[key] = true
          local a, b = bossPos(t)
          if a then
            local x, y = math.floor(a * 10 + 0.5) / 10, math.floor(b * 10 + 0.5) / 10
            local f = ""
            if UnitFacing then
              local okf, v = pcall(UnitFacing, t)
              if okf and v then f = math.floor(v * 100 + 0.5) / 100 end
            end
            local hp = pct(UnitHealth(t), UnitHealthMax(t))
            local tg = UnitName(t .. "target") or ""
            local l = bossLast[key]
            local moved = not l or math.abs(l[1] - x) + math.abs(l[2] - y) >= 1 or l[3] ~= f or l[5] ~= tg or math.abs(l[4] - hp) >= 3
            if all or moved then
              bossLast[key] = { x, y, f, hp, tg }
              table.insert(out, name .. ":" .. x .. ":" .. y .. ":" .. f .. ":" .. hp .. ":" .. tg)
            end
          end
        end
      end
    end
  end
  if table.getn(out) > 0 then put("B", table.concat(out, ";")) end
end
-- "H" lines: name:health%:power%:type;... (type 0 mana, 1 rage, 3 energy). Only in combat, only people whose
-- health or power moved 3% or more, plus everyone every 10 seconds. Feeds the raid frames on the planner's map.
local hpLast, hpFull = {}, 0
local function sampleHP()
  local now = GetTime()
  local all = now - hpFull >= 10
  if all then hpFull = now end
  local out = {}
  for _, u in ipairs(units()) do
    if UnitExists(u) then
      local name = UnitName(u)
      local h = UnitIsDeadOrGhost(u) and 0 or pct(UnitHealth(u), UnitHealthMax(u))
      local m = pct(UnitMana(u), UnitManaMax(u))
      local t = UnitPowerType and UnitPowerType(u) or 0
      if name then
        local l = hpLast[name]
        if all or not l or math.abs(l[1] - h) >= 3 or math.abs(l[2] - m) >= 3 or l[3] ~= t then
          hpLast[name] = { h, m, t }
          table.insert(out, name .. ":" .. h .. ":" .. m .. ":" .. t)
        end
      end
    end
  end
  if table.getn(out) > 0 then put("H", table.concat(out, ";")) end
end
local pf = CreateFrame("Frame")
pf:SetScript("OnUpdate", function()
  if not attach() then return end
  local now = GetTime()
  local every = UnitAffectingCombat("player") and 1 or 5
  if now - posT < every then return end
  posT = now
  samplePos()
  if every == 1 then sampleHP(); sampleBoss() end
end)
